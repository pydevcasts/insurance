from django.apps import AppConfig


class CommentConfig(AppConfig):
    name = 'comment'
    verbose_name = "پیام کاربر"
